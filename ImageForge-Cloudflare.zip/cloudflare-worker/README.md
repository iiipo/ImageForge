Cloudflare Worker proxy for ImageForge. Store OPENAI_API_KEY as a Worker secret.
