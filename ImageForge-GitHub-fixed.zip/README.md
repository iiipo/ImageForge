# ImageForge

Android-клиент + FastAPI backend для генерации изображений через OpenAI Image API.

## APK через GitHub Actions

После загрузки проекта в ветку `main` откройте **Actions → Build Android APK**. После успешной сборки внизу страницы запуска появится артефакт **ImageForge-debug-apk** с `app-debug.apk`.

## Backend

API-ключ намеренно не хранится в APK.

### Windows
1. Установите Python 3.11+.
2. Откройте папку `backend`.
3. В командной строке выполните `set OPENAI_API_KEY=ваш_ключ`.
4. Запустите `start_windows.bat`.
5. В приложении укажите адрес компьютера в локальной сети, например `http://192.168.1.2:8000`.

### Linux/macOS
```bash
cd backend
export OPENAI_API_KEY='ваш_ключ'
./start_linux.sh
```

## Режим модерации

В интерфейсе доступны официальные значения OpenAI `low` и `auto`. `low` означает менее строгую фильтрацию, но не отключает ограничения провайдера.
