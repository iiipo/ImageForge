package com.example.imageforge

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                ImageForgeScreen()
            }
        }
    }

    @Composable
    private fun ImageForgeScreen() {
        val scope = rememberCoroutineScope()
        val models = listOf("gpt-image-2.5-flare", "gpt-image-2.5-sunburst")
        val sizes = listOf("1024x1024", "1536x1024", "1024x1536")
        val qualities = listOf("low", "medium", "high", "xhigh", "max")
        val moderations = listOf("low", "auto")

        var backendUrl by remember { mutableStateOf("http://192.168.1.2:8000") }
        var prompt by remember { mutableStateOf("") }
        var model by remember { mutableStateOf(models[0]) }
        var size by remember { mutableStateOf(sizes[0]) }
        var quality by remember { mutableStateOf(qualities[1]) }
        var moderation by remember { mutableStateOf(moderations[0]) }
        var bitmap by remember { mutableStateOf<Bitmap?>(null) }
        var loading by remember { mutableStateOf(false) }
        var status by remember { mutableStateOf("Готово") }

        Surface(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("ImageForge", style = MaterialTheme.typography.headlineMedium)
                Text("Генератор изображений через OpenAI Image API")

                OutlinedTextField(
                    value = backendUrl,
                    onValueChange = { backendUrl = it },
                    label = { Text("Адрес backend") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    label = { Text("Промпт") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4
                )

                ChoiceRow("Модель", model) { model = next(models, model) }
                ChoiceRow("Размер", size) { size = next(sizes, size) }
                ChoiceRow("Качество", quality) { quality = next(qualities, quality) }
                ChoiceRow("Модерация", moderation) { moderation = next(moderations, moderation) }

                Text(
                    "low — менее строгая фильтрация, официально поддерживаемая OpenAI. " +
                        "Ограничения самого API не отключаются.",
                    style = MaterialTheme.typography.bodySmall
                )

                Button(
                    onClick = {
                        if (prompt.isBlank()) {
                            status = "Введите промпт"
                            return@Button
                        }
                        loading = true
                        status = "Генерация…"
                        scope.launch {
                            try {
                                val bytes = generateImage(backendUrl, prompt, model, size, quality, moderation)
                                bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                status = "Готово"
                            } catch (e: Exception) {
                                status = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
                            } finally {
                                loading = false
                            }
                        }
                    },
                    enabled = !loading,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (loading) "Генерирую…" else "Сгенерировать")
                }

                Text(status)

                bitmap?.let { result ->
                    Image(
                        bitmap = result.asImageBitmap(),
                        contentDescription = "Generated image",
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 260.dp, max = 520.dp),
                        contentScale = ContentScale.Fit
                    )
                    OutlinedButton(
                        onClick = {
                            try {
                                saveBitmap(result)
                                status = "Сохранено в Pictures/ImageForge"
                            } catch (e: Exception) {
                                status = "Не удалось сохранить: ${e.message}"
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Сохранить изображение") }
                }
            }
        }
    }

    @Composable
    private fun ChoiceRow(label: String, value: String, onClick: () -> Unit) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(label, modifier = Modifier.width(92.dp))
            OutlinedButton(onClick = onClick, shape = RoundedCornerShape(10.dp)) {
                Text(value)
            }
        }
    }

    private fun next(values: List<String>, current: String): String {
        val i = values.indexOf(current).coerceAtLeast(0)
        return values[(i + 1) % values.size]
    }

    private suspend fun generateImage(
        backendUrl: String,
        prompt: String,
        model: String,
        size: String,
        quality: String,
        moderation: String
    ): ByteArray = withContext(Dispatchers.IO) {
        val endpoint = backendUrl.trim().trimEnd('/') + "/generate"
        val connection = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 180_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        try {
            val body = JSONObject()
                .put("prompt", prompt)
                .put("model", model)
                .put("size", size)
                .put("quality", quality)
                .put("moderation", moderation)
                .toString()
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("HTTP $code: $text")
            val b64 = JSONObject(text).getString("image_base64")
            Base64.decode(b64, Base64.DEFAULT)
        } finally {
            connection.disconnect()
        }
    }

    private fun saveBitmap(bitmap: Bitmap) {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "ImageForge_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ImageForge")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("MediaStore insert failed")
        contentResolver.openOutputStream(uri)?.use { out ->
            check(bitmap.compress(Bitmap.CompressFormat.PNG, 100, out))
        } ?: error("Cannot open output stream")
    }
}
