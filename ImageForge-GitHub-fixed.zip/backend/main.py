import os
from typing import Literal

import httpx
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_IMAGES_URL = "https://api.openai.com/v1/images/generations"

app = FastAPI(title="ImageForge backend", version="1.0")


class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=32000)
    model: Literal["gpt-image-2.5-flare", "gpt-image-2.5-sunburst"] = "gpt-image-2.5-flare"
    size: Literal["1024x1024", "1536x1024", "1024x1536"] = "1024x1024"
    quality: Literal["low", "medium", "high", "xhigh", "max"] = "medium"
    moderation: Literal["low", "auto"] = "low"


@app.get("/health")
def health():
    return {"ok": True, "api_key_configured": bool(OPENAI_API_KEY)}


@app.post("/generate")
async def generate(req: GenerateRequest):
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail="OPENAI_API_KEY is not configured on the backend")

    payload = {
        "model": req.model,
        "prompt": req.prompt,
        "size": req.size,
        "quality": req.quality,
        "moderation": req.moderation,
        "output_format": "png",
        "n": 1,
    }
    headers = {
        "Authorization": f"Bearer {OPENAI_API_KEY}",
        "Content-Type": "application/json",
    }

    try:
        async with httpx.AsyncClient(timeout=180.0) as client:
            response = await client.post(OPENAI_IMAGES_URL, headers=headers, json=payload)
    except httpx.HTTPError as exc:
        raise HTTPException(status_code=502, detail=f"OpenAI connection error: {exc}") from exc

    if response.status_code >= 400:
        try:
            detail = response.json()
        except ValueError:
            detail = response.text
        raise HTTPException(status_code=response.status_code, detail=detail)

    data = response.json().get("data") or []
    if not data or not data[0].get("b64_json"):
        raise HTTPException(status_code=502, detail="OpenAI returned no image data")
    return {"image_base64": data[0]["b64_json"]}
