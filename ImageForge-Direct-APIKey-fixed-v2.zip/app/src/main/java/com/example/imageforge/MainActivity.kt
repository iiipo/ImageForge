package com.example.imageforge

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Screen() } }
    }

    @Composable
    fun Screen() {
        val scope=rememberCoroutineScope()
        val prefs=getSharedPreferences("imageforge", Context.MODE_PRIVATE)
        var key by remember { mutableStateOf(prefs.getString("key","") ?: "") }
        var prompt by remember { mutableStateOf("") }
        var bitmap by remember { mutableStateOf<Bitmap?>(null) }
        var status by remember { mutableStateOf("Готово") }
        var loading by remember { mutableStateOf(false) }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Text("ImageForge", style=MaterialTheme.typography.headlineMedium)
            OutlinedTextField(key,{key=it},label={Text("OpenAI API Key")},modifier=Modifier.fillMaxWidth())
            Button({prefs.edit().putString("key",key).apply(); status="Ключ сохранён"}) { Text("Сохранить ключ") }
            OutlinedTextField(prompt,{prompt=it},label={Text("Промпт")},modifier=Modifier.fillMaxWidth(),minLines=4)
            Button(enabled=!loading,onClick={
                loading=true; status="Генерация..."
                scope.launch {
                    try {
                        val bytes = generate(key,prompt)
                        bitmap = BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                        status="Готово"
                    }
                    catch(e:Exception){status="Ошибка: ${e.message}"}
                    loading=false
                }
            }, modifier=Modifier.fillMaxWidth()) { Text(if(loading)"Генерирую" else "Сгенерировать") }
            Text(status)
            bitmap?.let { Image(it.asImageBitmap(),null,Modifier.fillMaxWidth()) }
        }
    }

    private suspend fun generate(key:String,prompt:String):ByteArray=withContext(Dispatchers.IO){
        if(!key.startsWith("sk-")) throw Exception("Введите API key")
        val c=URL("https://api.openai.com/v1/images/generations").openConnection() as HttpURLConnection
        c.requestMethod="POST"; c.doOutput=true
        c.setRequestProperty("Authorization","Bearer $key")
        c.setRequestProperty("Content-Type","application/json")
        val body=JSONObject().put("model","gpt-image-1").put("prompt",prompt).put("size","1024x1024").toString()
        c.outputStream.use{it.write(body.toByteArray())}
        val stream = if (c.responseCode in 200..299) c.inputStream else c.errorStream
        val text = stream.bufferedReader().readText()

        if (c.responseCode !in 200..299) {
            throw Exception(text)
        }

        val json = JSONObject(text)
        val data = json.getJSONArray("data").getJSONObject(0)

        if (data.has("b64_json")) {
            Base64.decode(data.getString("b64_json"), Base64.DEFAULT)
        } else if (data.has("url")) {
            val image = URL(data.getString("url")).openStream().readBytes()
            image
        } else {
            throw Exception("Ответ API не содержит изображения")
        }
    }
}
